#include <stdio.h>

int main()
{
        int i, j;
        i = 2;
        printf("i = %d\n", i);
        return 0;
}
